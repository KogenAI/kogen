# Decisions and retained limits

No unresolved product choices remain for this bounded package. The Shaper
accepted private-home isolation, explicitly chose settings regeneration, and
then instructed: “Yes. Don't stop. Then approve.” in response to reassessment
against current main. That instruction authorizes finalizing the previously
presented lifecycle proposal and approving after reassessment; no separate
installation, credential migration, or recovery work is added.

## Resolved in this continuation

- Private process HOME and CODEX_HOME isolate automatic personal discovery;
  ordinary shell commands and checks retain the caller tool environment.
- Regenerate Kogen-owned settings on each Kogen launch; preserve session storage
  separately. Do not copy personal configuration or regenerate per shell command.
- Use main at bf68fd708a3faef0ef80883f47671f560b81a973 as the reassessed baseline,
  with original shaping and shaped_against history unchanged.
- Adopt the presented private, ignored, Kogen-owned runtime lifecycle: validate
  recognized existing paths, refuse unexpected occupants, retain sessions,
  preserve the authoritative caller login, and stop on incompatibility without
  destructive migration. [risks.yaml](risks.yaml) owns the detailed dimensions.

## Technical limits to retain

- The probe used Codex CLI 0.153.4 and the current file-backed ChatGPT login.
  Account authentication, actual Stop check and exact resume succeeded through
  an auth-file symlink. A synthetic login write preserved the symlink. Forced
  OAuth expiry/refresh and keyring/encrypted-store handoff were not tested.
- Private HOME plus CODEX_HOME removed the observed personal skills from the
  debug prompt while retaining the project skill. Full interactive launch,
  native-child context and hostile plugin/MCP sentinels still require live
  acceptance evidence through the implemented Kogen launcher.
- This is automatic Codex configuration/context isolation, not a security
  sandbox for commands or a way to bypass mandatory managed policy. Ordinary
  build tools intentionally keep their normal configuration.
- Original conversation timing was not supplied in the launch packet. The
  shaping started value uses the timestamp encoded in the minted Intent id,
  explicitly labeled as that source rather than an exact first-message time.

## Parked and excluded

Separate Codex installations, general credential-store migration, old personal
session migration and Build recovery remain non-goals, not approved backlog.
Full interactive/helper isolation is required Build acceptance work, not claimed
as already proved by the bounded shaping probes.

## Navigation

- [Contract and scope](INTENT.md)
- [Acceptance scenarios](scenarios.yaml)
- [Lifecycle and boundary risks](risks.yaml)
- [Current-main reassessment](evidence/continuation-reassessment.md)
- [Approval provenance](evidence/approval.md)
