# Isolate Kogen Codex sessions from personal configuration

Shaping is complete. The Shaper explicitly instructed approval after current-main
reassessment in this conversation. See [approval provenance](evidence/approval.md),
[resolved choices and limits](questions.md), and [lifecycle risks](risks.yaml).

## Problem and outcome

An unrelated Cloudflare MCP integration repeatedly reported authentication
errors during a Kogen Build. Kogen currently inherits the user's Codex
environment. Personal settings and integrations can therefore affect its
sessions without being chosen for the project. The supplied log does not
establish that the Build failed; its separate patch-context error is not
evidence of a plugin defect.

All Kogen-launched Shaping, Developer and Reviewer sessions should start with
a Kogen-controlled Codex environment. The same boundary must apply to continued
Shaping, exact Developer resume and native helpers. Reuse the existing Codex
account authentication and installed executable.

## Accepted decisions and provenance

In this shaping conversation the Shaper explicitly:

- Made separate Codex installation isolation a later concern and a non-goal.
- Chose all three session types, correcting the initial suggestion to isolate
  only Developer and Reviewer.
- Asked for all possible personal configuration isolation, including settings
  rather than only hooks.
- Chose existing authentication: “Existing, of course.”

During the continuation started 2026-09-10T05:57:04.107462Z, the Shaper answered
“Yes” to “Does that separation match what you want?” after an explanation of
the private project-specific Codex environment, retained project guidance and
hooks, excluded personal discovery, linked existing authentication, persistent
Developer sessions, inherited helper isolation, ordinary tool-environment
restoration, and failure without personal-environment fallback. This accepts
that isolation design, including the private process-home tradeoff.

In the same continuation, the Shaper explicitly chose “Yes! Regenerate” after
comparing regeneration on each Kogen launch with reuse of generated settings.
Kogen regenerates its own settings from current Kogen configuration on each
launch; it does not copy personal settings or regenerate on every agent shell
command. Persistent session storage remains separate and survives regeneration.
This settles settings regeneration, not all remaining file lifecycle choices.

The Shaper subsequently instructed “Yes. Don't stop. Then approve.” in response
to reassessment against current main. This authorizes the reassessment and
approval of the package with the previously presented lifecycle proposal,
modified by the explicit regeneration choice. The original shaping baseline
remains historical; intent.yaml records the separately reassessed baseline.
See evidence/approval.md for the decision sequence.

## Appetite

One Build: one Developer conversation with the configured two outer
resumptions. Centralize the launch environment, preserve the existing public
commands and lifecycle, and extend the existing offline and disposable live
fixtures. Do not create a configurable integration platform.

## Accepted isolation design

Use one project-local, ignored Kogen runtime area for persistent Codex session
storage and a private process home. The exact directory names are internal
implementation details; no new public command or configuration option is
proposed. Keep the storage stable across the Developer's exact resume. Keep
separate projects' runtime state separate.

Regenerate Kogen-owned settings on each Kogen launch from the current Kogen
configuration. Keep session contents separate from regenerated settings so this
does not erase the Developer conversation needed for exact resume. Do not copy
personal configuration. Regeneration avoids stale generated settings; it does
not guarantee compatibility with future Codex settings or session formats.

Resolve the installed executable and existing authentication source in the
original caller environment before constructing the child environment. Start
every root role through one shared environment policy, including the interactive
Port path used by Shaping. Do not place an exec-only option such as
`--ignore-user-config` in flags shared with the interactive TUI.

The source boundary is:

- Kogen owns generated Codex settings, role model/effort selection and runtime
  paths. Preserve the configured native helper profiles without substitution.
- Do not copy the personal Codex directory or personal configuration into the
  owned environment. Exclude personal profiles, settings, instructions, skills,
  rules, hooks, plugins, apps, MCP configuration, memories and session state.
- Give the Codex process private HOME, CODEX_HOME and applicable XDG discovery
  locations. Changing CODEX_HOME alone is insufficient: the installed CLI still
  discovers skills under the real HOME/.agents/skills.
- Explicitly disable plugin and app discovery for all Kogen roles. Exclude
  inherited Codex/provider configuration and session-attachment overrides from
  the launcher environment; do not let them select a personal daemon, provider,
  config path, thread or instruction source. Preserve environment needed to
  locate and run the installed executable and ordinary project tools. Test the
  relevant supported variables rather than claiming an OS-wide environment
  sandbox.
- Retain repository guidance and project-local skills, and load Kogen's tracked
  PreToolUse and Stop hooks from their existing project-owned source. Scope
  generated project trust to the actual checkout. Do not duplicate the hooks in
  the owned user directory. Personal parent-directory configuration must not
  become an implicit substitute for project configuration.
- Start fresh Shaping and draft continuation under the same policy. Continuation
  remains a fresh conversation reading the saved Draft; it does not import old
  personal transcripts. No changes to Intent identity or approval semantics.

This is isolation of automatic Codex configuration and context discovery. The
existing unsandboxed execution contract remains. Build tools can still read
their ordinary configuration; this does not prevent an arbitrary shell command
from reading a file in the user's home. Codex built-in capabilities and mandatory
system/account policies are not personal configuration to bypass.

## Authentication exception

For the currently verified file-backed ChatGPT login, bridge only the existing
CLI authentication file into the owned Codex home, using a reference rather
than a copied snapshot. The probe demonstrated real authenticated start/resume
through an auth.json symlink and a synthetic credential save that preserved
the symlink and updated its target. Force the matching credential-store mode
in the generated configuration rather than importing all personal settings.

Resolve the existing source from the incoming Codex home, falling back to its
standard location when no override exists. Keep the original source
authoritative. Do not import MCP OAuth credentials, personal settings or cached
session content with it. Do not print credentials or include them in prompts,
test evidence, tracked artifacts or diagnostic output. The runtime directory
must have private permissions; evidence records paths and outcomes only.

Never overwrite or unlink the source credential file as part of setup or
cleanup. Verify that a reused bridge points to the intended source and cannot
turn into a stale copied login unnoticed. Exercise credential writes with
synthetic credentials. Do not force a real account token refresh in tests.

If the existing authentication cannot be reused by the supported handoff,
report the compatibility problem before launching a model. Do not silently
switch accounts, initiate a new login, or fall back to the personal Codex
environment. General keyring/encrypted-store migration is outside this Build;
the current account's file-backed login was demonstrated. An actual OAuth
expiry/refresh was not forced during shaping and must not be claimed as proved.

## Ordinary tools and verification

Keep the real caller home and its existing XDG state available to ordinary
shell/build commands, using Codex's shell environment policy, while keeping
CODEX_HOME pointed at owned storage. Preserve whether optional caller variables
were set or absent; do not invent new tool defaults. Kogen's verification
subprocesses must use the same ordinary tool environment.

The probe established that shell environment policy does not automatically
restore HOME for hooks. Make the corresponding narrow restoration in the
tracked Kogen hook path, preserving direct invocation behavior when not launched
through isolation. Keep a single owner for the environment handoff and do not
weaken verification preflight, policy classification or role gating.

PreToolUse still blocks explicit Developer/helper gate execution. The root
Developer Stop hook still owns check, records the matching session/Candidate,
and blocks failed checks. The outer Build still owns non-check targets and
Review/rework. Preserve current structured scenario handoffs, attempt bindings,
finding dispositions, tracking integrity and independent per-scenario Review.
Shaping and Reviewer do not gain Developer Stop checks. Do not
run a recursive full live suite inside the fixture's check.

Native helpers must inherit the Codex discovery boundary, role and verification
policy from their root, even though their shell commands use the ordinary tool
environment. Prove the effective child context and environment in a live
fixture; a prompt asking the child to be isolated is not sufficient evidence.

## File lifecycle

[risks.yaml](risks.yaml) owns the detailed existing-path, ownership, mutation,
validation, Git and upgrade contract for private homes/settings, retained
sessions and the authentication bridge. Regeneration replaces only recognized
Kogen-owned settings and preserves active invocation isolation. Do not reset
the whole Codex home. Runtime paths remain under the already ignored
.kogen/runtime area. No new user-maintained configuration file is introduced.

## Failure and runtime behavior

Prepare the environment before model launch. An unusable owned directory,
unsupported required control or failed authentication handoff must stop visibly
without launching against the personal environment. Retain session storage
needed for exact resume; clean up only resources owned by the invocation.
Preserve personal configuration and normal independently launched Codex usage.
No per-run credentials, generated configuration or raw logs belong in commits.

## Non-goals

Separate Codex binaries/installations, containers or filesystem/network
sandboxing; changing normal build-tool credentials and configuration; personal
plugin repair/removal or Cloudflare reauthentication; fixing the reported
apply_patch context mismatch; opt-in integration profiles or a settings UI;
arbitrary-project installation; Build recovery or migration of old personal
sessions; bypassing mandatory managed policies; changing models or resumption
budgets; adding project AGENTS.md files.

## Verification and navigation

[Acceptance scenarios](scenarios.yaml) use the existing check and live targets.
Offline tests prove Kogen's launch and environment contract with synthetic
homes and credentials. Live evidence must prove actual discovery, authenticated
execution, hooks, helpers and exact resume, including the real interactive
Shaping entry point. Fake argv alone is insufficient.

- [Identity and permitted guarded paths](intent.yaml)
- [Resolved choices and retained limits](questions.md)
- [Lifecycle and boundary risks](risks.yaml)
- [Current-main reassessment](evidence/continuation-reassessment.md)
- [Approval provenance](evidence/approval.md)
- [Bounded shaping probe evidence](evidence/shaping-probes.md)
- [References](references.yaml)
